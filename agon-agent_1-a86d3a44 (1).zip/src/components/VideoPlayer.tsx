import { useEffect, useRef, useState } from 'react';
import { Maximize, Pause, Play, Volume2, VolumeX } from 'lucide-react';

function formatTime(seconds: number) {
  if (!isFinite(seconds)) seconds = 0;
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

export function VideoPlayer({ src }: { src: string }) {
  const ref = useRef<HTMLVideoElement>(null);
  const [playing, setPlaying] = useState(true);
  const [muted, setMuted] = useState(true);
  const [current, setCurrent] = useState(0);
  const [duration, setDuration] = useState(0);

  useEffect(() => {
    const video = ref.current;
    if (!video) return;
    video.muted = muted;
    video.play().catch(() => setPlaying(false));
  }, [src, muted]);

  useEffect(() => {
    const video = ref.current;
    if (!video) return;

    const onTimeUpdate = () => {
      setCurrent(video.currentTime);
      if (video.duration && !isNaN(video.duration)) {
        setDuration(video.duration);
      }
    };
    const onEnded = () => setPlaying(false);

    video.addEventListener('timeupdate', onTimeUpdate);
    video.addEventListener('loadedmetadata', onTimeUpdate);
    video.addEventListener('ended', onEnded);

    return () => {
      video.removeEventListener('timeupdate', onTimeUpdate);
      video.removeEventListener('loadedmetadata', onTimeUpdate);
      video.removeEventListener('ended', onEnded);
    };
  }, []);

  const togglePlay = () => {
    const video = ref.current;
    if (!video) return;
    if (video.paused) {
      video.play();
      setPlaying(true);
    } else {
      video.pause();
      setPlaying(false);
    }
  };

  const seek = (e: React.MouseEvent<HTMLDivElement>) => {
    const video = ref.current;
    if (!video || !duration) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const pct = (e.clientX - rect.left) / rect.width;
    video.currentTime = Math.max(0, Math.min(duration, pct * duration));
  };

  const fullscreen = () => ref.current?.requestFullscreen();
  const progress = duration > 0 ? (current / duration) * 100 : 0;

  return (
    <div className="relative w-full h-full group">
      <video
        ref={ref}
        src={src}
        className="w-full h-full object-contain bg-black"
        playsInline
        loop
        autoPlay
        onClick={togglePlay}
      />
      <div className="absolute inset-x-0 bottom-0 p-3 pt-10 bg-gradient-to-t from-black/80 to-transparent opacity-0 group-hover:opacity-100 transition">
        <div
          onClick={seek}
          className="h-1 w-full bg-white/20 rounded-full cursor-pointer mb-3 overflow-hidden"
        >
          <div
            className="h-full bg-[color:var(--color-accent)]"
            style={{ width: `${progress}%` }}
          />
        </div>
        <div className="flex items-center gap-3 text-white">
          <button
            onClick={togglePlay}
            className="hover:text-[color:var(--color-accent)] transition"
            aria-label="Play/pause"
          >
            {playing ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
          </button>
          <button
            onClick={() => setMuted((m) => !m)}
            className="hover:text-[color:var(--color-accent)] transition"
            aria-label="Mute"
          >
            {muted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
          </button>
          <div className="font-mono text-[10px] tracking-widest opacity-80">
            {formatTime(current)} / {formatTime(duration)}
          </div>
          <button
            onClick={fullscreen}
            className="ml-auto hover:text-[color:var(--color-accent)] transition"
            aria-label="Fullscreen"
          >
            <Maximize className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
}
