import './App.css';
import CreateVideoPage from './pages/CreateVideoPage';

function App() {
  return (
    <div className="grain min-h-screen">
      <CreateVideoPage />
    </div>
  );
}

export default App;
