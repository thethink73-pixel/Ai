import { useEffect, useMemo, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Aperture,
  CircleCheck,
  Clapperboard,
  Download,
  ImageUp,
  Loader2,
  MonitorPlay,
  Play,
  RefreshCcw,
  Sparkles,
  TriangleAlert,
  X,
} from 'lucide-react';
import { VideoPlayer } from '../components/VideoPlayer';

const MODELS = [
  { id: 'veo-3.0-generate-001', label: 'Veo 3', hint: 'Highest fidelity · slowest' },
  { id: 'veo-3.0-fast-generate-001', label: 'Veo 3 Fast', hint: 'Balanced speed · quality' },
  { id: 'veo-2.0-generate-001', label: 'Veo 2', hint: 'Classic · fastest' },
];

const STARTER_PROMPTS = [
  'A lone lighthouse keeper walks across rain-slick basalt cliffs at dusk, storm clouds churning behind, 35mm anamorphic.',
  'Overhead shot of a hand pouring molten caramel over a stack of pancakes, morning light, shallow depth of field.',
  'Neon-drenched Tokyo alley at night, reflections in puddles, a stray cat pads past a ramen stall, cinematic slow dolly.',
  'Time-lapse of a paper crane unfolding itself into a flock, museum lighting, matte painting aesthetic.',
];

type AspectRatio = '16:9' | '9:16';

type GenerationPhase = 'idle' | 'generating' | 'completed' | 'error';

interface ImageUpload {
  base64: string;
  mimeType: string;
}

interface GenerationPayload {
  prompt: string;
  aspectRatio: AspectRatio;
  negativePrompt?: string;
  image?: ImageUpload;
  model: string;
}

async function startGeneration(payload: GenerationPayload): Promise<{ operationName: string }> {
  const res = await fetch('/api/veo-generate', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      prompt: payload.prompt,
      aspectRatio: payload.aspectRatio,
      negativePrompt: payload.negativePrompt,
      imageBase64: payload.image?.base64,
      imageMimeType: payload.image?.mimeType,
      model: payload.model,
    }),
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data?.error || `Request failed (${res.status})`);
  }
  if (!data.operationName) {
    throw new Error('Server did not return an operation name.');
  }
  return { operationName: data.operationName };
}

async function checkStatus(operationName: string): Promise<{
  done: boolean;
  videoUrl?: string;
  error?: string;
}> {
  const res = await fetch(`/api/veo-status?name=${encodeURIComponent(operationName)}`);
  const data = await res.json().catch(() => ({ done: false }));
  if (!res.ok) {
    throw new Error(data?.error || `Status check failed (${res.status})`);
  }
  return data;
}

async function pollGeneration(
  operationName: string,
  options: {
    signal?: AbortSignal;
    onTick?: (seconds: number) => void;
    timeoutMs?: number;
  } = {}
): Promise<{ videoUrl: string }> {
  const start = Date.now();
  let interval = 6000;
  const { signal, onTick, timeoutMs = 600000 } = options;

  while (true) {
    if (signal?.aborted) {
      throw new DOMException('Aborted', 'AbortError');
    }
    if (Date.now() - start > timeoutMs) {
      throw new Error('Timed out waiting for video generation.');
    }

    const status = await checkStatus(operationName);
    if (status.done) {
      if (status.error) {
        throw new Error(status.error);
      }
      if (!status.videoUrl) {
        throw new Error('Generation finished but no video URL was returned.');
      }
      return { videoUrl: status.videoUrl };
    }

    onTick?.(Math.floor((Date.now() - start) / 1000));

    await new Promise<void>((resolve, reject) => {
      const t = setTimeout(() => resolve(), interval);
      signal?.addEventListener('abort', () => {
        clearTimeout(t);
        reject(new DOMException('Aborted', 'AbortError'));
      });
    });

    interval = Math.min(interval + 2000, 15000);
  }
}

async function readFileAsBase64(file: File): Promise<ImageUpload> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = String(reader.result || '');
      const idx = result.indexOf(',');
      resolve({
        base64: idx >= 0 ? result.slice(idx + 1) : result,
        mimeType: file.type || 'image/png',
      });
    };
    reader.onerror = () => reject(reader.error || new Error('Failed to read file'));
    reader.readAsDataURL(file);
  });
}

function Header({ phase }: { phase: GenerationPhase }) {
  return (
    <header className="border-b border-[color:var(--color-line)] px-6 lg:px-10 py-4 flex items-center justify-between">
      <div className="flex items-center gap-2.5">
        <div className="w-8 h-8 rounded-md bg-[color:var(--color-accent)] flex items-center justify-center">
          <Aperture className="w-4 h-4 text-[color:var(--color-canvas)]" strokeWidth={2.5} />
        </div>
        <div>
          <div className="text-sm font-semibold tracking-tight leading-none">Vellum Studio</div>
          <div className="text-[10px] uppercase tracking-[0.28em] text-[color:var(--color-ink-dim)] mt-0.5">
            Reel · 001
          </div>
        </div>
      </div>
      <div className="hidden md:flex items-center gap-6 text-xs uppercase tracking-[0.24em] text-[color:var(--color-ink-dim)]">
        <div className="flex items-center gap-1.5">
          <span
            className={`w-1.5 h-1.5 rounded-full ${
              phase === 'generating' ? 'bg-[color:var(--color-accent)] rec-dot' : 'bg-[color:var(--color-ok)]'
            }`}
          />
          {phase === 'generating' ? 'Recording' : 'Standby'}
        </div>
        <div>Powered by Veo</div>
      </div>
    </header>
  );
}

function Hero() {
  return (
    <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4 pt-4">
      <div>
        <div className="text-[11px] uppercase tracking-[0.3em] text-[color:var(--color-ink-dim)] mb-3">
          Create — New Video
        </div>
        <h1 className="text-5xl md:text-6xl leading-[0.95] tracking-tight">
          Direct a short.
          <span className="block italic text-[color:var(--color-accent-2)]">In a single take.</span>
        </h1>
      </div>
      <p className="text-[color:var(--color-ink-dim)] max-w-xs text-sm leading-relaxed">
        Write the scene, drop a reference frame, and let Veo shoot it — up to 8 seconds of cinema on demand.
      </p>
    </div>
  );
}

function Panel({ children }: { children: React.ReactNode }) {
  return (
    <div className="bg-[color:var(--color-panel)] border border-[color:var(--color-line)] rounded-2xl p-6">
      {children}
    </div>
  );
}

function StepHeader({ index, title }: { index: string; title: string }) {
  return (
    <div className="flex items-baseline gap-3 mb-4">
      <span className="font-mono text-[10px] text-[color:var(--color-accent)] tracking-widest">{index}</span>
      <h3 className="text-sm uppercase tracking-[0.24em] text-[color:var(--color-ink-dim)]">{title}</h3>
    </div>
  );
}

function AspectRatioButton({
  current,
  value,
  onClick,
  label,
  ratio,
}: {
  current: AspectRatio;
  value: AspectRatio;
  onClick: (value: AspectRatio) => void;
  label: string;
  ratio: string;
}) {
  const active = current === value;
  return (
    <button
      onClick={() => onClick(value)}
      className={`flex-1 flex items-center gap-3 px-4 py-3 rounded-lg border transition ${
        active
          ? 'border-[color:var(--color-accent)] bg-[color:var(--color-accent)]/5'
          : 'border-[color:var(--color-line)] hover:border-[color:var(--color-ink-dim)]'
      }`}
    >
      <div
        className={`${ratio} border ${
          active ? 'border-[color:var(--color-accent)]' : 'border-[color:var(--color-ink-dim)]'
        } rounded-sm`}
      />
      <div className="text-left">
        <div className="text-sm font-medium">{value}</div>
        <div className="text-[10px] uppercase tracking-wider text-[color:var(--color-ink-dim)]">{label}</div>
      </div>
    </button>
  );
}

function ImageUploader({
  imagePreview,
  onFile,
  onClear,
}: {
  imagePreview: string | null;
  onFile: (file: File | null) => void;
  onClear: () => void;
}) {
  const [dragging, setDragging] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  if (imagePreview) {
    return (
      <div className="relative rounded-xl overflow-hidden border border-[color:var(--color-line)]">
        <img src={imagePreview} alt="reference" className="w-full h-48 object-cover" />
        <button
          onClick={onClear}
          className="absolute top-2 right-2 w-8 h-8 rounded-full bg-black/70 backdrop-blur flex items-center justify-center hover:bg-[color:var(--color-err)]/80 transition"
          aria-label="Remove reference image"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    );
  }

  const handleDrop = (e: React.DragEvent<HTMLLabelElement>) => {
    e.preventDefault();
    setDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file && file.type.startsWith('image/')) {
      onFile(file);
    }
  };

  return (
    <label
      onDragOver={(e) => {
        e.preventDefault();
        setDragging(true);
      }}
      onDragLeave={() => setDragging(false)}
      onDrop={handleDrop}
      className={`block cursor-pointer rounded-xl border-2 border-dashed p-8 text-center transition ${
        dragging
          ? 'border-[color:var(--color-accent)] bg-[color:var(--color-accent)]/5'
          : 'border-[color:var(--color-line)] hover:border-[color:var(--color-ink-dim)]'
      }`}
    >
      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) onFile(file);
        }}
      />
      <ImageUp className="w-6 h-6 mx-auto text-[color:var(--color-ink-dim)] mb-2" />
      <div className="text-sm text-[color:var(--color-ink-dim)]">
        Drop an image, or <span className="text-[color:var(--color-accent)] underline underline-offset-2">browse</span>
      </div>
      <div className="text-[10px] uppercase tracking-wider text-[color:var(--color-ink-dim)] mt-2">
        Used as the opening frame
      </div>
    </label>
  );
}

function ViewfinderCorners() {
  const base = 'absolute w-6 h-6 border-[color:var(--color-accent)]/70';
  return (
    <>
      <div className={`${base} top-3 left-3 border-t-2 border-l-2`} />
      <div className={`${base} top-3 right-3 border-t-2 border-r-2`} />
      <div className={`${base} bottom-3 left-3 border-b-2 border-l-2`} />
      <div className={`${base} bottom-3 right-3 border-b-2 border-r-2`} />
    </>
  );
}

function Monitor({
  phase,
  aspectRatio,
  videoUrl,
  elapsed,
  errorMsg,
  onDownload,
  onRegenerate,
  canDownload,
}: {
  phase: GenerationPhase;
  aspectRatio: AspectRatio;
  videoUrl: string | null;
  elapsed: number;
  errorMsg: string | null;
  onDownload: () => void;
  onRegenerate: () => void;
  canDownload: boolean;
}) {
  const ratioClass = aspectRatio === '16:9' ? 'aspect-[16/9]' : 'aspect-[9/16] max-h-[70vh] mx-auto';

  return (
    <div className="bg-[color:var(--color-panel)] border border-[color:var(--color-line)] rounded-2xl p-5">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2 text-xs uppercase tracking-[0.24em] text-[color:var(--color-ink-dim)]">
          <MonitorPlay className="w-3.5 h-3.5" />
          Monitor · {aspectRatio}
        </div>
        <div className="font-mono text-[10px] text-[color:var(--color-ink-dim)] tracking-widest">
          TC {String(Math.floor(elapsed / 60)).padStart(2, '0')}:
          {String(elapsed % 60).padStart(2, '0')}:00
        </div>
      </div>

      <div
        className={`relative w-full ${ratioClass} bg-black rounded-xl overflow-hidden border border-[color:var(--color-line)]`}
      >
        <ViewfinderCorners />
        <AnimatePresence mode="wait">
          {phase === 'idle' && (
            <motion.div
              key="idle"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 flex flex-col items-center justify-center text-center px-6"
            >
              <Play className="w-10 h-10 text-[color:var(--color-ink-dim)]/50 mb-3" />
              <div className="text-[color:var(--color-ink-dim)] text-sm">Awaiting the first take</div>
              <div className="text-[10px] uppercase tracking-[0.28em] text-[color:var(--color-ink-dim)]/60 mt-2">
                Slate is empty
              </div>
            </motion.div>
          )}

          {phase === 'generating' && (
            <motion.div
              key="gen"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0"
            >
              <div className="scanline" />
              <div className="absolute inset-0 flex flex-col items-center justify-center text-center px-6">
                <div className="flex items-center gap-2 mb-4">
                  <span className="w-2 h-2 rounded-full bg-[color:var(--color-accent)] rec-dot" />
                  <span className="font-mono text-xs tracking-widest text-[color:var(--color-accent)]">REC</span>
                </div>
                <div className="text-2xl md:text-3xl font-display italic">Rolling the take…</div>
                <div className="text-xs text-[color:var(--color-ink-dim)] mt-2 max-w-sm">
                  Veo is composing the shot. This usually takes 30–120 seconds — hang tight.
                </div>
                <div className="mt-6 flex items-center gap-3 font-mono text-xs text-[color:var(--color-ink-dim)]">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  {elapsed}s elapsed
                </div>
              </div>
            </motion.div>
          )}

          {phase === 'completed' && videoUrl && (
            <motion.div
              key="done"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0"
            >
              <VideoPlayer src={videoUrl} />
            </motion.div>
          )}

          {phase === 'error' && (
            <motion.div
              key="err"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 flex flex-col items-center justify-center text-center px-6"
            >
              <TriangleAlert className="w-8 h-8 text-[color:var(--color-err)] mb-3" />
              <div className="text-lg">Cut. Something went wrong.</div>
              <div className="text-sm text-[color:var(--color-ink-dim)] mt-2 max-w-md break-words">
                {errorMsg || 'Unknown error'}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <div className="mt-4 flex items-center justify-between gap-3">
        <div className="flex items-center gap-2 text-xs text-[color:var(--color-ink-dim)]">
          {phase === 'completed' && (
            <>
              <CircleCheck className="w-4 h-4 text-[color:var(--color-ok)]" /> Take approved
            </>
          )}
          {phase === 'error' && (
            <>
              <TriangleAlert className="w-4 h-4 text-[color:var(--color-err)]" /> Take rejected
            </>
          )}
          {phase === 'generating' && 'Working the shot…'}
          {phase === 'idle' && 'Ready when you are.'}
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={onDownload}
            disabled={!canDownload || phase !== 'completed'}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg border border-[color:var(--color-line)] text-sm hover:border-[color:var(--color-accent)] hover:text-[color:var(--color-accent)] disabled:opacity-40 disabled:hover:border-[color:var(--color-line)] disabled:hover:text-[color:var(--color-ink)] transition"
          >
            <Download className="w-4 h-4" /> Download
          </button>
          <button
            onClick={onRegenerate}
            disabled={phase === 'generating'}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg border border-[color:var(--color-line)] text-sm hover:border-[color:var(--color-accent-2)] hover:text-[color:var(--color-accent-2)] disabled:opacity-40 transition"
          >
            <RefreshCcw className="w-4 h-4" /> Regenerate
          </button>
        </div>
      </div>
    </div>
  );
}

function Marquee() {
  const items = useMemo(
    () => [
      'VELLUM STUDIO',
      '—',
      'DIRECTED BY YOU',
      '—',
      'SHOT BY VEO',
      '—',
      'A ONE-TAKE PICTURE',
      'VELLUM STUDIO',
      '—',
      'DIRECTED BY YOU',
      '—',
      'SHOT BY VEO',
      '—',
      'A ONE-TAKE PICTURE',
    ],
    []
  );

  return (
    <div className="mt-24 border-y border-[color:var(--color-line)] py-4 overflow-hidden">
      <div className="marquee-track flex gap-10 whitespace-nowrap font-display italic text-[color:var(--color-ink-dim)] text-xl tracking-tight">
        {items.concat(items).map((text, i) => (
          <span key={i}>{text}</span>
        ))}
      </div>
    </div>
  );
}

export default function CreateVideoPage() {
  const [phase, setPhase] = useState<GenerationPhase>('idle');
  const [prompt, setPrompt] = useState('');
  const [negativePrompt, setNegativePrompt] = useState('');
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>('16:9');
  const [model, setModel] = useState(MODELS[1].id);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [downloadUri, setDownloadUri] = useState<string | null>(null);
  const [elapsed, setElapsed] = useState(0);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const abortRef = useRef<AbortController | null>(null);
  const lastPayloadRef = useRef<GenerationPayload | null>(null);

  useEffect(() => {
    return () => {
      if (imagePreview) URL.revokeObjectURL(imagePreview);
    };
  }, [imagePreview]);

  const canGenerate = prompt.trim().length > 0 && phase !== 'generating';

  async function runGeneration(payload: GenerationPayload) {
    setErrorMsg(null);
    setVideoUrl(null);
    setDownloadUri(null);
    setElapsed(0);
    setPhase('generating');

    const controller = new AbortController();
    abortRef.current?.abort();
    abortRef.current = controller;

    try {
      const { operationName } = await startGeneration(payload);
      const result = await pollGeneration(operationName, {
        signal: controller.signal,
        onTick: (seconds) => setElapsed(seconds),
      });

      setVideoUrl(result.videoUrl);

      try {
        const uri = result.videoUrl
          ? new URL(result.videoUrl, window.location.origin).searchParams.get('uri')
          : null;
        if (uri) setDownloadUri(uri);
      } catch {
        // ignore URL parsing errors for non-proxied URLs
      }

      setPhase('completed');
    } catch (err) {
      if (err instanceof DOMException && err.name === 'AbortError') {
        return;
      }
      console.error(err);
      setErrorMsg(
        err instanceof Error && err.message ? err.message : 'Something went wrong.'
      );
      setPhase('error');
    }
  }

  async function handleGenerate() {
    if (!canGenerate) return;

    const image = imageFile ? await readFileAsBase64(imageFile) : undefined;
    const payload: GenerationPayload = {
      prompt: prompt.trim(),
      aspectRatio,
      negativePrompt: negativePrompt.trim() || undefined,
      image,
      model,
    };
    lastPayloadRef.current = payload;
    runGeneration(payload);
  }

  function handleImageFile(file: File | null) {
    if (imagePreview) URL.revokeObjectURL(imagePreview);
    if (file) {
      setImageFile(file);
      setImagePreview(URL.createObjectURL(file));
    } else {
      setImageFile(null);
      setImagePreview(null);
    }
  }

  function handleRegenerate() {
    const last = lastPayloadRef.current;
    if (!last) {
      handleGenerate();
      return;
    }
    runGeneration(last);
  }

  function handleCancel() {
    abortRef.current?.abort();
    setPhase('idle');
    setElapsed(0);
  }

  function handleDownload() {
    if (downloadUri) {
      const filename = `veo-${Date.now()}.mp4`;
      const url = `/api/veo-video?uri=${encodeURIComponent(
        downloadUri
      )}&download=1&filename=${encodeURIComponent(filename)}`;
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      a.remove();
    } else if (videoUrl?.startsWith('data:')) {
      const a = document.createElement('a');
      a.href = videoUrl;
      a.download = `veo-${Date.now()}.mp4`;
      document.body.appendChild(a);
      a.click();
      a.remove();
    }
  }

  return (
    <div className="min-h-screen text-[color:var(--color-ink)]">
      <Header phase={phase} />
      <main className="max-w-[1400px] mx-auto px-6 lg:px-10 pt-8 pb-24">
        <Hero />
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mt-10">
          <section className="lg:col-span-5 space-y-6">
            <Panel>
              <StepHeader index="01" title="The scene" />
              <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="Describe your shot. Camera moves, mood, lighting, subject..."
                rows={6}
                className="w-full bg-transparent outline-none text-[color:var(--color-ink)] placeholder:text-[color:var(--color-ink-dim)]/60 text-lg leading-relaxed resize-none"
              />
              <div className="flex flex-wrap gap-2 mt-4">
                {STARTER_PROMPTS.map((text, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setPrompt(text)}
                    className="text-xs px-3 py-1.5 rounded-full border border-[color:var(--color-line)] text-[color:var(--color-ink-dim)] hover:text-[color:var(--color-ink)] hover:border-[color:var(--color-accent)]/50 transition"
                  >
                    <Sparkles className="inline w-3 h-3 mr-1 -mt-0.5" />
                    Starter {idx + 1}
                  </button>
                ))}
              </div>
            </Panel>

            <Panel>
              <StepHeader index="02" title="Reference image (optional)" />
              <ImageUploader
                imagePreview={imagePreview}
                onFile={handleImageFile}
                onClear={() => handleImageFile(null)}
              />
            </Panel>

            <Panel>
              <StepHeader index="03" title="Format & model" />
              <div className="space-y-5">
                <div>
                  <div className="text-xs uppercase tracking-[0.2em] text-[color:var(--color-ink-dim)] mb-2">
                    Aspect ratio
                  </div>
                  <div className="flex gap-2">
                    <AspectRatioButton
                      current={aspectRatio}
                      value="16:9"
                      onClick={setAspectRatio}
                      label="Landscape"
                      ratio="w-9 h-5"
                    />
                    <AspectRatioButton
                      current={aspectRatio}
                      value="9:16"
                      onClick={setAspectRatio}
                      label="Portrait"
                      ratio="w-5 h-9"
                    />
                  </div>
                </div>

                <div>
                  <div className="text-xs uppercase tracking-[0.2em] text-[color:var(--color-ink-dim)] mb-2">
                    Model
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    {MODELS.map((m) => (
                      <button
                        key={m.id}
                        type="button"
                        onClick={() => setModel(m.id)}
                        className={`text-left p-3 rounded-lg border transition ${
                          model === m.id
                            ? 'border-[color:var(--color-accent)] bg-[color:var(--color-accent)]/5'
                            : 'border-[color:var(--color-line)] hover:border-[color:var(--color-ink-dim)]'
                        }`}
                      >
                        <div className="text-sm font-medium">{m.label}</div>
                        <div className="text-[10px] uppercase tracking-wider text-[color:var(--color-ink-dim)] mt-0.5">
                          {m.hint}
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <div className="text-xs uppercase tracking-[0.2em] text-[color:var(--color-ink-dim)] mb-2">
                    Negative prompt (optional)
                  </div>
                  <input
                    type="text"
                    value={negativePrompt}
                    onChange={(e) => setNegativePrompt(e.target.value)}
                    placeholder="e.g. blurry, low resolution, cartoon"
                    className="w-full bg-[color:var(--color-panel-2)] border border-[color:var(--color-line)] rounded-lg px-3 py-2.5 text-sm outline-none focus:border-[color:var(--color-accent)]/60"
                  />
                </div>
              </div>
            </Panel>

            <div className="flex items-center gap-3">
              <button
                onClick={handleGenerate}
                disabled={!canGenerate}
                className="group relative flex-1 py-4 px-6 rounded-xl bg-[color:var(--color-accent)] text-[color:var(--color-canvas)] font-semibold text-lg tracking-tight disabled:opacity-40 disabled:cursor-not-allowed hover:brightness-110 transition overflow-hidden"
              >
                <span className="relative z-10 flex items-center justify-center gap-2">
                  {phase === 'generating' ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" /> Rolling…
                    </>
                  ) : (
                    <>
                      <Clapperboard className="w-5 h-5" /> Roll camera
                    </>
                  )}
                </span>
              </button>
              {phase === 'generating' && (
                <button
                  onClick={handleCancel}
                  className="py-4 px-5 rounded-xl border border-[color:var(--color-line)] hover:border-[color:var(--color-err)] hover:text-[color:var(--color-err)] transition text-sm"
                >
                  Cancel
                </button>
              )}
            </div>
          </section>

          <section className="lg:col-span-7">
            <div className="sticky top-8">
              <Monitor
                phase={phase}
                aspectRatio={aspectRatio}
                videoUrl={videoUrl}
                elapsed={elapsed}
                errorMsg={errorMsg}
                onDownload={handleDownload}
                onRegenerate={handleRegenerate}
                canDownload={!!(downloadUri || videoUrl?.startsWith('data:'))}
              />
            </div>
          </section>
        </div>
        <Marquee />
      </main>
    </div>
  );
}
