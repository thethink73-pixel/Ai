import { startGeneration } from './lib/videoProviders/index.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const {
      prompt,
      aspectRatio,
      negativePrompt,
      imageBase64,
      imageMimeType,
      model,
      provider = 'gemini-veo',
    } = req.body || {};

    const result = await startGeneration(provider, {
      prompt,
      aspectRatio,
      negativePrompt,
      imageBase64,
      imageMimeType,
      model,
    });

    return res.status(202).json({ operationName: result.operationName });
  } catch (err) {
    console.error('[veo-generate] error:', err);
    const status = err.status || 500;
    return res.status(status).json({
      error: err.message || 'Failed to start video generation.',
    });
  }
}
