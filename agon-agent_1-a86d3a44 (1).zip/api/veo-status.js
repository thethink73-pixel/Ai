import { getStatus } from './lib/videoProviders/index.js';

/**
 * Poll endpoint for long-running video generation.
 *
 * When the operation is complete we return a proxied video URL
 * (`/api/veo-video?uri=...`) so the browser never sees the upstream
 * Gemini URI or API key.
 */

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const { name, provider = 'gemini-veo' } = req.query || {};
    if (!name) {
      return res.status(400).json({ error: 'Missing operation name.' });
    }

    const status = await getStatus(provider, name);

    if (!status.done) {
      return res.status(200).json({ done: false });
    }

    if (status.error) {
      return res.status(200).json({ done: true, error: status.error });
    }

    const videoUrl = `/api/veo-video?provider=${encodeURIComponent(
      provider
    )}&uri=${encodeURIComponent(status.videoUri)}`;

    return res.status(200).json({ done: true, videoUrl });
  } catch (err) {
    console.error('[veo-status] error:', err);
    const status = err.status || 500;
    return res.status(status).json({
      error: err.message || 'Failed to check generation status.',
    });
  }
}
