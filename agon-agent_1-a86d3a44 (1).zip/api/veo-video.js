import { fetchVideo } from './lib/videoProviders/index.js';

/**
 * Secure video-download proxy.
 *
 * Fetches the generated video from Gemini using the server-side API key and
 * streams the bytes back to the client. The browser only ever sees this route.
 */

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const { uri, provider = 'gemini-veo', download, filename } = req.query || {};
    if (!uri) {
      return res.status(400).json({ error: 'Missing video uri.' });
    }

    const upstream = await fetchVideo(provider, uri);

    // Stream headers from upstream.
    const contentType = upstream.headers.get('content-type') || 'video/mp4';
    res.setHeader('Content-Type', contentType);

    if (download === '1') {
      const safeName = (filename || 'generated-video.mp4').replace(/[^a-zA-Z0-9._-]/g, '_');
      res.setHeader('Content-Disposition', `attachment; filename="${safeName}"`);
    }

    // Copy cache-related headers when present.
    const cacheControl = upstream.headers.get('cache-control');
    if (cacheControl) res.setHeader('Cache-Control', cacheControl);
    const contentLength = upstream.headers.get('content-length');
    if (contentLength) res.setHeader('Content-Length', contentLength);

    if (upstream.body) {
      for await (const chunk of upstream.body) {
        res.write(chunk);
      }
    }

    return res.end();
  } catch (err) {
    console.error('[veo-video] error:', err);
    const status = err.status || 500;
    return res.status(status).json({
      error: err.message || 'Failed to fetch generated video.',
    });
  }
}
